﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szachy_Projekt
{
    public enum figureValue
    {

        Empty,
        BlackPawn,
        BlackKnight,
        BlackBishop,
        BlackRook,
        BlackQueen,
        WhitePawn = 11,
        WhiteKnight,
        WhiteBishop,
        WhiteRook,
        WhiteQueen,
        BlackKing = 1000,
        WhiteKing = 1100,
        BlackPiece = 10,
        WhitePiece = 100,
        Dot = 10000


    }
}
